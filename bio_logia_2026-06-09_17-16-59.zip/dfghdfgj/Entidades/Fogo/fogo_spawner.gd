extends Node

@export var fire_scene: PackedScene

func spawn_fire():

	var fire = fire_scene.instantiate()

	fire.position = Vector2(
		randf_range(50, 750),
		randf_range(50, 300)
	)

	get_parent().add_child(fire)

func _ready():
	for i in range(5):
		spawn_fire()

func _on_timer_timeout():
	spawn_fire()
