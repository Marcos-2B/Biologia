extends Area2D

@export var max_life := 100.0

var life := 100.0

func _ready():
	life = max_life

func take_damage(damage):

	life -= damage

	var p = max(life / max_life, 0.0)

	scale = Vector2.ONE * p
	modulate.a = p

	if life <= 0:
		queue_free()
