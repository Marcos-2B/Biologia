extends CharacterBody2D

@export var speed := 300.0
@export var water_scene: PackedScene

func _physics_process(delta):

	var direction = Input.get_axis(
		"mover_esquerda",
		"mover_direita"
	)

	velocity.x = direction * speed

	move_and_slide()

	if Input.is_action_just_pressed("shoot"):
		shoot()

func shoot():

	var water = water_scene.instantiate()

	water.global_position = $Marker2D.global_position

	get_tree().current_scene.add_child(water)
