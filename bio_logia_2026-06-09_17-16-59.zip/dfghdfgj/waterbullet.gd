extends Area2D

@export var speed := 600.0
@export var damage := 20.0

func _process(delta):
	position.y -= speed * delta

func _on_area_entered(area):

	if area.has_method("take_damage"):
		area.take_damage(damage)

	queue_free()
